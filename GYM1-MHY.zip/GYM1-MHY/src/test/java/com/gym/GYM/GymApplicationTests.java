package com.gym.GYM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymApplicationTests {

	@Test
	void contextLoads() {
	}

}
